--
-- PostgreSQL database dump
--

\restrict 6KQLfaMs85rLOlfu4AfuPTndWJtkw2JrOBV5beheDs9frn48q3ZsEKrSn9dn0La

-- Dumped from database version 15.15
-- Dumped by pg_dump version 18.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AdjustmentType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AdjustmentType" AS ENUM (
    'ENTRY',
    'EXIT'
);


ALTER TYPE public."AdjustmentType" OWNER TO postgres;

--
-- Name: BillingCycle; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BillingCycle" AS ENUM (
    'MONTHLY',
    'YEARLY'
);


ALTER TYPE public."BillingCycle" OWNER TO postgres;

--
-- Name: CashStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CashStatus" AS ENUM (
    'OPEN',
    'CLOSED'
);


ALTER TYPE public."CashStatus" OWNER TO postgres;

--
-- Name: InventoryMovementType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InventoryMovementType" AS ENUM (
    'SALE',
    'CREDIT_NOTE',
    'ADJUSTMENT_ENTRY',
    'ADJUSTMENT_EXIT',
    'TRANSFER'
);


ALTER TYPE public."InventoryMovementType" OWNER TO postgres;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'DRAFT',
    'ISSUED',
    'PAID',
    'OVERDUE',
    'CANCELLED'
);


ALTER TYPE public."InvoiceStatus" OWNER TO postgres;

--
-- Name: InvoiceType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InvoiceType" AS ENUM (
    'FISCAL',
    'NON_FISCAL'
);


ALTER TYPE public."InvoiceType" OWNER TO postgres;

--
-- Name: MasterRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MasterRole" AS ENUM (
    'SUPER_ADMIN',
    'SUPPORT'
);


ALTER TYPE public."MasterRole" OWNER TO postgres;

--
-- Name: MovementType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MovementType" AS ENUM (
    'OPENING',
    'SALE',
    'PAYMENT',
    'MANUAL_ENTRY',
    'MANUAL_EXIT',
    'CLOSING'
);


ALTER TYPE public."MovementType" OWNER TO postgres;

--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'CASH',
    'TRANSFER',
    'CARD',
    'CREDIT',
    'MIXED'
);


ALTER TYPE public."PaymentMethod" OWNER TO postgres;

--
-- Name: PlanType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PlanType" AS ENUM (
    'BASIC',
    'PROFESSIONAL',
    'ENTERPRISE'
);


ALTER TYPE public."PlanType" OWNER TO postgres;

--
-- Name: QuoteStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QuoteStatus" AS ENUM (
    'OPEN',
    'ACCEPTED',
    'REJECTED',
    'CONVERTED'
);


ALTER TYPE public."QuoteStatus" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'ADMINISTRATOR',
    'SUPERVISOR',
    'OPERATOR',
    'CASHIER'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: SubscriptionStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SubscriptionStatus" AS ENUM (
    'ACTIVE',
    'SUSPENDED',
    'EXPIRED',
    'CANCELLED'
);


ALTER TYPE public."SubscriptionStatus" OWNER TO postgres;

--
-- Name: TenantStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TenantStatus" AS ENUM (
    'ACTIVE',
    'SUSPENDED',
    'CANCELLED',
    'PENDING'
);


ALTER TYPE public."TenantStatus" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "userId" text,
    action text NOT NULL,
    entity text NOT NULL,
    "entityId" text NOT NULL,
    changes jsonb,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO postgres;

--
-- Name: Branch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Branch" (
    id text NOT NULL,
    name text NOT NULL,
    address text,
    phone text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    code text,
    email text,
    "managerId" text
);


ALTER TABLE public."Branch" OWNER TO postgres;

--
-- Name: CashMovement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CashMovement" (
    id text NOT NULL,
    "cashRegisterId" text NOT NULL,
    type public."MovementType" NOT NULL,
    concept text NOT NULL,
    amount numeric(10,2) NOT NULL,
    method public."PaymentMethod" NOT NULL,
    "invoiceId" text,
    "paymentId" text,
    "userId" text NOT NULL,
    "movementDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    observations text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CashMovement" OWNER TO postgres;

--
-- Name: CashRegister; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CashRegister" (
    id text NOT NULL,
    "branchId" text NOT NULL,
    status public."CashStatus" DEFAULT 'CLOSED'::public."CashStatus" NOT NULL,
    "initialAmount" numeric(10,2) NOT NULL,
    "finalAmount" numeric(10,2),
    difference numeric(10,2) DEFAULT 0,
    "openedAt" timestamp(3) without time zone NOT NULL,
    "closedAt" timestamp(3) without time zone,
    "openedBy" text NOT NULL,
    "closedBy" text,
    observations text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CashRegister" OWNER TO postgres;

--
-- Name: Category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Category" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Category" OWNER TO postgres;

--
-- Name: Client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Client" (
    id text NOT NULL,
    name text NOT NULL,
    identification text NOT NULL,
    email text,
    phone text,
    address text,
    "creditLimit" numeric(10,2) DEFAULT 0,
    "creditDays" integer DEFAULT 30 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Client" OWNER TO postgres;

--
-- Name: CreditNote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CreditNote" (
    id text NOT NULL,
    number text NOT NULL,
    ncf text,
    "invoiceId" text NOT NULL,
    reason text NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    tax numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) NOT NULL,
    "issueDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CreditNote" OWNER TO postgres;

--
-- Name: CreditNoteItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CreditNoteItem" (
    id text NOT NULL,
    "creditNoteId" text NOT NULL,
    "productId" text,
    description text NOT NULL,
    quantity numeric(10,2) NOT NULL,
    price numeric(10,2) NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CreditNoteItem" OWNER TO postgres;

--
-- Name: InventoryAdjustment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InventoryAdjustment" (
    id text NOT NULL,
    "branchId" text NOT NULL,
    type public."AdjustmentType" NOT NULL,
    reason text NOT NULL,
    "userId" text NOT NULL,
    "adjustmentDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    observations text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."InventoryAdjustment" OWNER TO postgres;

--
-- Name: InventoryAdjustmentItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InventoryAdjustmentItem" (
    id text NOT NULL,
    "adjustmentId" text NOT NULL,
    "productId" text NOT NULL,
    "previousQuantity" numeric(10,2) NOT NULL,
    "adjustmentQuantity" numeric(10,2) NOT NULL,
    "newQuantity" numeric(10,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."InventoryAdjustmentItem" OWNER TO postgres;

--
-- Name: InventoryMovement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InventoryMovement" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "branchId" text NOT NULL,
    type public."InventoryMovementType" NOT NULL,
    quantity numeric(10,2) NOT NULL,
    balance numeric(10,2) NOT NULL,
    "documentType" text,
    "documentId" text,
    "userId" text NOT NULL,
    "movementDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    observations text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."InventoryMovement" OWNER TO postgres;

--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    number text NOT NULL,
    ncf text,
    "clientId" text,
    type public."InvoiceType" DEFAULT 'FISCAL'::public."InvoiceType" NOT NULL,
    status public."InvoiceStatus" DEFAULT 'ISSUED'::public."InvoiceStatus" NOT NULL,
    "paymentMethod" public."PaymentMethod" NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    tax numeric(10,2) DEFAULT 0 NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) NOT NULL,
    balance numeric(10,2) DEFAULT 0 NOT NULL,
    "issueDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "userId" text NOT NULL,
    "branchId" text,
    observations text,
    "cancelledAt" timestamp(3) without time zone,
    "cancellationReason" text,
    "cancelledBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Invoice" OWNER TO postgres;

--
-- Name: InvoiceItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InvoiceItem" (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "productId" text,
    description text NOT NULL,
    quantity numeric(10,2) NOT NULL,
    price numeric(10,2) NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."InvoiceItem" OWNER TO postgres;

--
-- Name: MasterUser; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MasterUser" (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    role public."MasterRole" DEFAULT 'SUPPORT'::public."MasterRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text
);


ALTER TABLE public."MasterUser" OWNER TO postgres;

--
-- Name: NcfSequence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NcfSequence" (
    id text NOT NULL,
    prefix text NOT NULL,
    description text,
    "startRange" integer NOT NULL,
    "endRange" integer NOT NULL,
    "currentNumber" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "validFrom" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "validUntil" timestamp(3) without time zone,
    "branchId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NcfSequence" OWNER TO postgres;

--
-- Name: Payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "clientId" text NOT NULL,
    "invoiceId" text,
    amount numeric(10,2) NOT NULL,
    method public."PaymentMethod" NOT NULL,
    reference text,
    "paymentDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    observations text,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Payment" OWNER TO postgres;

--
-- Name: Product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    code text NOT NULL,
    barcode text,
    name text NOT NULL,
    description text,
    "categoryId" text NOT NULL,
    brand text,
    unit text DEFAULT 'UNIT'::text NOT NULL,
    "salePrice" numeric(10,2) NOT NULL,
    cost numeric(10,2),
    "hasTax" boolean DEFAULT true NOT NULL,
    "taxPercent" numeric(5,2) DEFAULT 18 NOT NULL,
    "controlsStock" boolean DEFAULT true NOT NULL,
    "minStock" numeric(10,2) DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "imageUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Product" OWNER TO postgres;

--
-- Name: Quote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Quote" (
    id text NOT NULL,
    number text NOT NULL,
    "clientId" text,
    status public."QuoteStatus" DEFAULT 'OPEN'::public."QuoteStatus" NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    tax numeric(10,2) DEFAULT 0 NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    total numeric(10,2) NOT NULL,
    "validUntil" timestamp(3) without time zone,
    "userId" text NOT NULL,
    "convertedToInvoiceId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Quote" OWNER TO postgres;

--
-- Name: QuoteItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."QuoteItem" (
    id text NOT NULL,
    "quoteId" text NOT NULL,
    "productId" text,
    description text NOT NULL,
    quantity numeric(10,2) NOT NULL,
    price numeric(10,2) NOT NULL,
    discount numeric(10,2) DEFAULT 0 NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."QuoteItem" OWNER TO postgres;

--
-- Name: Stock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Stock" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "branchId" text NOT NULL,
    quantity numeric(10,2) DEFAULT 0 NOT NULL,
    "minStock" numeric(10,2) DEFAULT 0 NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Stock" OWNER TO postgres;

--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    plan public."PlanType" NOT NULL,
    status public."SubscriptionStatus" DEFAULT 'ACTIVE'::public."SubscriptionStatus" NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    "billingCycle" public."BillingCycle" DEFAULT 'MONTHLY'::public."BillingCycle" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Subscription" OWNER TO postgres;

--
-- Name: Task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Task" (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    "clientId" text,
    "userId" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    priority text DEFAULT 'MEDIUM'::text NOT NULL
);


ALTER TABLE public."Task" OWNER TO postgres;

--
-- Name: Tenant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Tenant" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    email text NOT NULL,
    phone text,
    address text,
    country text DEFAULT 'DO'::text NOT NULL,
    status public."TenantStatus" DEFAULT 'ACTIVE'::public."TenantStatus" NOT NULL,
    plan public."PlanType" DEFAULT 'BASIC'::public."PlanType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    rnc text,
    logo text,
    subdomain text DEFAULT ''::text NOT NULL,
    "customDomain" text,
    "databaseName" text DEFAULT ''::text NOT NULL,
    "databaseUrl" text DEFAULT ''::text NOT NULL,
    settings jsonb,
    limits jsonb,
    "billingEmail" text DEFAULT ''::text NOT NULL,
    "subscriptionId" text,
    "trialEndsAt" timestamp(6) without time zone,
    "lastActiveAt" timestamp(6) without time zone
);


ALTER TABLE public."Tenant" OWNER TO postgres;

--
-- Name: TenantActivity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TenantActivity" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    action text NOT NULL,
    description text NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."TenantActivity" OWNER TO postgres;

--
-- Name: TenantInvoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TenantInvoice" (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    amount numeric(65,30) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'DOP'::text NOT NULL,
    status public."InvoiceStatus" DEFAULT 'DRAFT'::public."InvoiceStatus" NOT NULL,
    description text,
    "periodStart" timestamp(3) without time zone NOT NULL,
    "periodEnd" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "paymentMethod" text,
    "paymentReference" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TenantInvoice" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    phone text,
    role public."Role" DEFAULT 'OPERATOR'::public."Role" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "branchId" text
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: WhatsAppTemplate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WhatsAppTemplate" (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    subject text,
    message text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."WhatsAppTemplate" OWNER TO postgres;

--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AuditLog" (id, "userId", action, entity, "entityId", changes, "ipAddress", "userAgent", "createdAt") FROM stdin;
\.


--
-- Data for Name: Branch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Branch" (id, name, address, phone, "isActive", "createdAt", "updatedAt", code, email, "managerId") FROM stdin;
670b64c6-e9a3-4298-8968-7500b8656666	Sucursal Principal	Dirección no especificada	809-555-0300	t	2026-02-16 21:24:14.872	2026-02-16 21:24:14.872	MAIN001	admin@miempresademo.com	\N
\.


--
-- Data for Name: CashMovement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CashMovement" (id, "cashRegisterId", type, concept, amount, method, "invoiceId", "paymentId", "userId", "movementDate", observations, "createdAt") FROM stdin;
\.


--
-- Data for Name: CashRegister; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CashRegister" (id, "branchId", status, "initialAmount", "finalAmount", difference, "openedAt", "closedAt", "openedBy", "closedBy", observations, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Category" (id, name, description, "isActive", "createdAt", "updatedAt") FROM stdin;
e61be129-0eea-400f-8486-d09e2cb07518	General	Categoría por defecto para productos	t	2026-02-16 21:24:14.876	2026-02-16 21:24:14.876
\.


--
-- Data for Name: Client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Client" (id, name, identification, email, phone, address, "creditLimit", "creditDays", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CreditNote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CreditNote" (id, number, ncf, "invoiceId", reason, subtotal, tax, total, "issueDate", "userId", "createdAt") FROM stdin;
\.


--
-- Data for Name: CreditNoteItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CreditNoteItem" (id, "creditNoteId", "productId", description, quantity, price, subtotal, "createdAt") FROM stdin;
\.


--
-- Data for Name: InventoryAdjustment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InventoryAdjustment" (id, "branchId", type, reason, "userId", "adjustmentDate", observations, "createdAt") FROM stdin;
\.


--
-- Data for Name: InventoryAdjustmentItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InventoryAdjustmentItem" (id, "adjustmentId", "productId", "previousQuantity", "adjustmentQuantity", "newQuantity", "createdAt") FROM stdin;
\.


--
-- Data for Name: InventoryMovement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InventoryMovement" (id, "productId", "branchId", type, quantity, balance, "documentType", "documentId", "userId", "movementDate", observations, "createdAt") FROM stdin;
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Invoice" (id, number, ncf, "clientId", type, status, "paymentMethod", subtotal, tax, discount, total, balance, "issueDate", "dueDate", "userId", "branchId", observations, "cancelledAt", "cancellationReason", "cancelledBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: InvoiceItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InvoiceItem" (id, "invoiceId", "productId", description, quantity, price, discount, subtotal, "createdAt") FROM stdin;
\.


--
-- Data for Name: MasterUser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MasterUser" (id, email, password, name, role, "createdAt", "updatedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: NcfSequence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NcfSequence" (id, prefix, description, "startRange", "endRange", "currentNumber", "isActive", "validFrom", "validUntil", "branchId", "createdAt", "updatedAt") FROM stdin;
abd9d2ce-bc31-4e94-81bd-c61481b7cabe	B01	Facturas de Crédito Fiscal	1	1000000	0	t	2026-02-16 21:24:14.878	\N	670b64c6-e9a3-4298-8968-7500b8656666	2026-02-16 21:24:14.878	2026-02-16 21:24:14.878
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Payment" (id, "clientId", "invoiceId", amount, method, reference, "paymentDate", observations, "userId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Product" (id, code, barcode, name, description, "categoryId", brand, unit, "salePrice", cost, "hasTax", "taxPercent", "controlsStock", "minStock", "isActive", "imageUrl", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Quote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Quote" (id, number, "clientId", status, subtotal, tax, discount, total, "validUntil", "userId", "convertedToInvoiceId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: QuoteItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."QuoteItem" (id, "quoteId", "productId", description, quantity, price, discount, subtotal, "createdAt") FROM stdin;
\.


--
-- Data for Name: Stock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Stock" (id, "productId", "branchId", quantity, "minStock", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Subscription" (id, "tenantId", plan, status, "startDate", "endDate", "billingCycle", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Task" (id, title, description, "clientId", "userId", status, "dueDate", "completedAt", "createdAt", "updatedAt", priority) FROM stdin;
\.


--
-- Data for Name: Tenant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Tenant" (id, name, slug, email, phone, address, country, status, plan, "createdAt", "updatedAt", rnc, logo, subdomain, "customDomain", "databaseName", "databaseUrl", settings, limits, "billingEmail", "subscriptionId", "trialEndsAt", "lastActiveAt") FROM stdin;
\.


--
-- Data for Name: TenantActivity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TenantActivity" (id, "tenantId", action, description, metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: TenantInvoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TenantInvoice" (id, "tenantId", amount, currency, status, description, "periodStart", "periodEnd", "paidAt", "paymentMethod", "paymentReference", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, password, name, phone, role, "isActive", "lastLogin", "createdAt", "updatedAt", "branchId") FROM stdin;
093c8f60-ff2f-4472-a577-89ecefc237db	admin@miempresademo.com	$2a$10$alDlCU4NgvJaxO9VjeCjZerWA6iNCCz6rsa64.0LMNML5YPWD94HG	Administrador	\N	ADMINISTRATOR	t	\N	2026-02-16 21:24:14.862	2026-02-16 21:24:14.874	670b64c6-e9a3-4298-8968-7500b8656666
\.


--
-- Data for Name: WhatsAppTemplate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WhatsAppTemplate" (id, name, type, subject, message, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Branch Branch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Branch"
    ADD CONSTRAINT "Branch_pkey" PRIMARY KEY (id);


--
-- Name: CashMovement CashMovement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CashMovement"
    ADD CONSTRAINT "CashMovement_pkey" PRIMARY KEY (id);


--
-- Name: CashRegister CashRegister_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CashRegister"
    ADD CONSTRAINT "CashRegister_pkey" PRIMARY KEY (id);


--
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY (id);


--
-- Name: Client Client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_pkey" PRIMARY KEY (id);


--
-- Name: CreditNoteItem CreditNoteItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CreditNoteItem"
    ADD CONSTRAINT "CreditNoteItem_pkey" PRIMARY KEY (id);


--
-- Name: CreditNote CreditNote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CreditNote"
    ADD CONSTRAINT "CreditNote_pkey" PRIMARY KEY (id);


--
-- Name: InventoryAdjustmentItem InventoryAdjustmentItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryAdjustmentItem"
    ADD CONSTRAINT "InventoryAdjustmentItem_pkey" PRIMARY KEY (id);


--
-- Name: InventoryAdjustment InventoryAdjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryAdjustment"
    ADD CONSTRAINT "InventoryAdjustment_pkey" PRIMARY KEY (id);


--
-- Name: InventoryMovement InventoryMovement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryMovement"
    ADD CONSTRAINT "InventoryMovement_pkey" PRIMARY KEY (id);


--
-- Name: InvoiceItem InvoiceItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InvoiceItem"
    ADD CONSTRAINT "InvoiceItem_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: MasterUser MasterUser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MasterUser"
    ADD CONSTRAINT "MasterUser_pkey" PRIMARY KEY (id);


--
-- Name: NcfSequence NcfSequence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NcfSequence"
    ADD CONSTRAINT "NcfSequence_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: QuoteItem QuoteItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QuoteItem"
    ADD CONSTRAINT "QuoteItem_pkey" PRIMARY KEY (id);


--
-- Name: Quote Quote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Quote"
    ADD CONSTRAINT "Quote_pkey" PRIMARY KEY (id);


--
-- Name: Stock Stock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: Task Task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_pkey" PRIMARY KEY (id);


--
-- Name: TenantActivity TenantActivity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TenantActivity"
    ADD CONSTRAINT "TenantActivity_pkey" PRIMARY KEY (id);


--
-- Name: TenantInvoice TenantInvoice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TenantInvoice"
    ADD CONSTRAINT "TenantInvoice_pkey" PRIMARY KEY (id);


--
-- Name: Tenant Tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: WhatsAppTemplate WhatsAppTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WhatsAppTemplate"
    ADD CONSTRAINT "WhatsAppTemplate_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog_action_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_action_idx" ON public."AuditLog" USING btree (action);


--
-- Name: AuditLog_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_createdAt_idx" ON public."AuditLog" USING btree ("createdAt");


--
-- Name: AuditLog_entity_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_entity_idx" ON public."AuditLog" USING btree (entity);


--
-- Name: AuditLog_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_userId_idx" ON public."AuditLog" USING btree ("userId");


--
-- Name: Branch_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Branch_code_idx" ON public."Branch" USING btree (code);


--
-- Name: Branch_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Branch_code_key" ON public."Branch" USING btree (code);


--
-- Name: Branch_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Branch_isActive_idx" ON public."Branch" USING btree ("isActive");


--
-- Name: Branch_managerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Branch_managerId_idx" ON public."Branch" USING btree ("managerId");


--
-- Name: Branch_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Branch_name_idx" ON public."Branch" USING btree (name);


--
-- Name: Branch_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Branch_name_key" ON public."Branch" USING btree (name);


--
-- Name: CashMovement_cashRegisterId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CashMovement_cashRegisterId_idx" ON public."CashMovement" USING btree ("cashRegisterId");


--
-- Name: CashMovement_movementDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CashMovement_movementDate_idx" ON public."CashMovement" USING btree ("movementDate");


--
-- Name: CashMovement_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CashMovement_type_idx" ON public."CashMovement" USING btree (type);


--
-- Name: CashRegister_branchId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CashRegister_branchId_idx" ON public."CashRegister" USING btree ("branchId");


--
-- Name: CashRegister_openedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CashRegister_openedAt_idx" ON public."CashRegister" USING btree ("openedAt");


--
-- Name: CashRegister_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CashRegister_status_idx" ON public."CashRegister" USING btree (status);


--
-- Name: Category_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Category_isActive_idx" ON public."Category" USING btree ("isActive");


--
-- Name: Category_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Category_name_idx" ON public."Category" USING btree (name);


--
-- Name: Category_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Category_name_key" ON public."Category" USING btree (name);


--
-- Name: Client_identification_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Client_identification_idx" ON public."Client" USING btree (identification);


--
-- Name: Client_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Client_isActive_idx" ON public."Client" USING btree ("isActive");


--
-- Name: Client_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Client_name_idx" ON public."Client" USING btree (name);


--
-- Name: CreditNoteItem_creditNoteId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CreditNoteItem_creditNoteId_idx" ON public."CreditNoteItem" USING btree ("creditNoteId");


--
-- Name: CreditNote_invoiceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CreditNote_invoiceId_idx" ON public."CreditNote" USING btree ("invoiceId");


--
-- Name: CreditNote_issueDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CreditNote_issueDate_idx" ON public."CreditNote" USING btree ("issueDate");


--
-- Name: CreditNote_ncf_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CreditNote_ncf_key" ON public."CreditNote" USING btree (ncf);


--
-- Name: CreditNote_number_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CreditNote_number_idx" ON public."CreditNote" USING btree (number);


--
-- Name: CreditNote_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CreditNote_number_key" ON public."CreditNote" USING btree (number);


--
-- Name: InventoryAdjustmentItem_adjustmentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InventoryAdjustmentItem_adjustmentId_idx" ON public."InventoryAdjustmentItem" USING btree ("adjustmentId");


--
-- Name: InventoryAdjustmentItem_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InventoryAdjustmentItem_productId_idx" ON public."InventoryAdjustmentItem" USING btree ("productId");


--
-- Name: InventoryAdjustment_adjustmentDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InventoryAdjustment_adjustmentDate_idx" ON public."InventoryAdjustment" USING btree ("adjustmentDate");


--
-- Name: InventoryAdjustment_branchId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InventoryAdjustment_branchId_idx" ON public."InventoryAdjustment" USING btree ("branchId");


--
-- Name: InventoryMovement_branchId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InventoryMovement_branchId_idx" ON public."InventoryMovement" USING btree ("branchId");


--
-- Name: InventoryMovement_movementDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InventoryMovement_movementDate_idx" ON public."InventoryMovement" USING btree ("movementDate");


--
-- Name: InventoryMovement_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InventoryMovement_productId_idx" ON public."InventoryMovement" USING btree ("productId");


--
-- Name: InventoryMovement_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InventoryMovement_type_idx" ON public."InventoryMovement" USING btree (type);


--
-- Name: InvoiceItem_invoiceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InvoiceItem_invoiceId_idx" ON public."InvoiceItem" USING btree ("invoiceId");


--
-- Name: InvoiceItem_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InvoiceItem_productId_idx" ON public."InvoiceItem" USING btree ("productId");


--
-- Name: Invoice_clientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Invoice_clientId_idx" ON public."Invoice" USING btree ("clientId");


--
-- Name: Invoice_dueDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Invoice_dueDate_idx" ON public."Invoice" USING btree ("dueDate");


--
-- Name: Invoice_issueDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Invoice_issueDate_idx" ON public."Invoice" USING btree ("issueDate");


--
-- Name: Invoice_ncf_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Invoice_ncf_idx" ON public."Invoice" USING btree (ncf);


--
-- Name: Invoice_ncf_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Invoice_ncf_key" ON public."Invoice" USING btree (ncf);


--
-- Name: Invoice_number_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Invoice_number_idx" ON public."Invoice" USING btree (number);


--
-- Name: Invoice_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Invoice_number_key" ON public."Invoice" USING btree (number);


--
-- Name: Invoice_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Invoice_status_idx" ON public."Invoice" USING btree (status);


--
-- Name: MasterUser_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "MasterUser_email_idx" ON public."MasterUser" USING btree (email);


--
-- Name: MasterUser_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "MasterUser_email_key" ON public."MasterUser" USING btree (email);


--
-- Name: NcfSequence_branchId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "NcfSequence_branchId_idx" ON public."NcfSequence" USING btree ("branchId");


--
-- Name: NcfSequence_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "NcfSequence_isActive_idx" ON public."NcfSequence" USING btree ("isActive");


--
-- Name: NcfSequence_prefix_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "NcfSequence_prefix_idx" ON public."NcfSequence" USING btree (prefix);


--
-- Name: NcfSequence_validUntil_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "NcfSequence_validUntil_idx" ON public."NcfSequence" USING btree ("validUntil");


--
-- Name: Payment_clientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_clientId_idx" ON public."Payment" USING btree ("clientId");


--
-- Name: Payment_invoiceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_invoiceId_idx" ON public."Payment" USING btree ("invoiceId");


--
-- Name: Payment_paymentDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_paymentDate_idx" ON public."Payment" USING btree ("paymentDate");


--
-- Name: Product_barcode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_barcode_idx" ON public."Product" USING btree (barcode);


--
-- Name: Product_barcode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Product_barcode_key" ON public."Product" USING btree (barcode);


--
-- Name: Product_categoryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_categoryId_idx" ON public."Product" USING btree ("categoryId");


--
-- Name: Product_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_code_idx" ON public."Product" USING btree (code);


--
-- Name: Product_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Product_code_key" ON public."Product" USING btree (code);


--
-- Name: Product_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_isActive_idx" ON public."Product" USING btree ("isActive");


--
-- Name: QuoteItem_quoteId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "QuoteItem_quoteId_idx" ON public."QuoteItem" USING btree ("quoteId");


--
-- Name: Quote_clientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Quote_clientId_idx" ON public."Quote" USING btree ("clientId");


--
-- Name: Quote_convertedToInvoiceId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Quote_convertedToInvoiceId_key" ON public."Quote" USING btree ("convertedToInvoiceId");


--
-- Name: Quote_number_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Quote_number_idx" ON public."Quote" USING btree (number);


--
-- Name: Quote_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Quote_number_key" ON public."Quote" USING btree (number);


--
-- Name: Quote_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Quote_status_idx" ON public."Quote" USING btree (status);


--
-- Name: Stock_branchId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Stock_branchId_idx" ON public."Stock" USING btree ("branchId");


--
-- Name: Stock_productId_branchId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Stock_productId_branchId_key" ON public."Stock" USING btree ("productId", "branchId");


--
-- Name: Stock_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Stock_productId_idx" ON public."Stock" USING btree ("productId");


--
-- Name: Subscription_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Subscription_status_idx" ON public."Subscription" USING btree (status);


--
-- Name: Subscription_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Subscription_tenantId_idx" ON public."Subscription" USING btree ("tenantId");


--
-- Name: Task_clientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_clientId_idx" ON public."Task" USING btree ("clientId");


--
-- Name: Task_priority_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_priority_idx" ON public."Task" USING btree (priority);


--
-- Name: Task_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_status_idx" ON public."Task" USING btree (status);


--
-- Name: Task_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_userId_idx" ON public."Task" USING btree ("userId");


--
-- Name: TenantActivity_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TenantActivity_createdAt_idx" ON public."TenantActivity" USING btree ("createdAt");


--
-- Name: TenantActivity_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TenantActivity_tenantId_idx" ON public."TenantActivity" USING btree ("tenantId");


--
-- Name: TenantInvoice_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TenantInvoice_status_idx" ON public."TenantInvoice" USING btree (status);


--
-- Name: TenantInvoice_tenantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TenantInvoice_tenantId_idx" ON public."TenantInvoice" USING btree ("tenantId");


--
-- Name: Tenant_customDomain_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Tenant_customDomain_key" ON public."Tenant" USING btree ("customDomain");


--
-- Name: Tenant_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Tenant_slug_idx" ON public."Tenant" USING btree (slug);


--
-- Name: Tenant_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Tenant_slug_key" ON public."Tenant" USING btree (slug);


--
-- Name: Tenant_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Tenant_status_idx" ON public."Tenant" USING btree (status);


--
-- Name: Tenant_subdomain_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Tenant_subdomain_key" ON public."Tenant" USING btree (subdomain);


--
-- Name: User_branchId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_branchId_idx" ON public."User" USING btree ("branchId");


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_isActive_idx" ON public."User" USING btree ("isActive");


--
-- Name: User_role_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_role_idx" ON public."User" USING btree (role);


--
-- Name: WhatsAppTemplate_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WhatsAppTemplate_isActive_idx" ON public."WhatsAppTemplate" USING btree ("isActive");


--
-- Name: WhatsAppTemplate_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WhatsAppTemplate_name_key" ON public."WhatsAppTemplate" USING btree (name);


--
-- Name: WhatsAppTemplate_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WhatsAppTemplate_type_idx" ON public."WhatsAppTemplate" USING btree (type);


--
-- Name: Branch Branch_managerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Branch"
    ADD CONSTRAINT "Branch_managerId_fkey" FOREIGN KEY ("managerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CashMovement CashMovement_cashRegisterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CashMovement"
    ADD CONSTRAINT "CashMovement_cashRegisterId_fkey" FOREIGN KEY ("cashRegisterId") REFERENCES public."CashRegister"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CashMovement CashMovement_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CashMovement"
    ADD CONSTRAINT "CashMovement_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CashRegister CashRegister_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CashRegister"
    ADD CONSTRAINT "CashRegister_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public."Branch"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CashRegister CashRegister_closedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CashRegister"
    ADD CONSTRAINT "CashRegister_closedBy_fkey" FOREIGN KEY ("closedBy") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CashRegister CashRegister_openedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CashRegister"
    ADD CONSTRAINT "CashRegister_openedBy_fkey" FOREIGN KEY ("openedBy") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CreditNoteItem CreditNoteItem_creditNoteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CreditNoteItem"
    ADD CONSTRAINT "CreditNoteItem_creditNoteId_fkey" FOREIGN KEY ("creditNoteId") REFERENCES public."CreditNote"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CreditNoteItem CreditNoteItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CreditNoteItem"
    ADD CONSTRAINT "CreditNoteItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CreditNote CreditNote_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CreditNote"
    ADD CONSTRAINT "CreditNote_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CreditNote CreditNote_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CreditNote"
    ADD CONSTRAINT "CreditNote_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: InventoryAdjustmentItem InventoryAdjustmentItem_adjustmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryAdjustmentItem"
    ADD CONSTRAINT "InventoryAdjustmentItem_adjustmentId_fkey" FOREIGN KEY ("adjustmentId") REFERENCES public."InventoryAdjustment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InventoryAdjustmentItem InventoryAdjustmentItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryAdjustmentItem"
    ADD CONSTRAINT "InventoryAdjustmentItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: InventoryAdjustment InventoryAdjustment_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryAdjustment"
    ADD CONSTRAINT "InventoryAdjustment_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public."Branch"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: InventoryAdjustment InventoryAdjustment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryAdjustment"
    ADD CONSTRAINT "InventoryAdjustment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: InventoryMovement InventoryMovement_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryMovement"
    ADD CONSTRAINT "InventoryMovement_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public."Branch"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: InventoryMovement InventoryMovement_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryMovement"
    ADD CONSTRAINT "InventoryMovement_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: InventoryMovement InventoryMovement_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryMovement"
    ADD CONSTRAINT "InventoryMovement_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: InvoiceItem InvoiceItem_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InvoiceItem"
    ADD CONSTRAINT "InvoiceItem_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InvoiceItem InvoiceItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InvoiceItem"
    ADD CONSTRAINT "InvoiceItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoice Invoice_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public."Branch"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoice Invoice_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoice Invoice_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MasterUser MasterUser_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MasterUser"
    ADD CONSTRAINT "MasterUser_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NcfSequence NcfSequence_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NcfSequence"
    ADD CONSTRAINT "NcfSequence_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public."Branch"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payment Payment_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Payment Payment_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payment Payment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Product Product_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: QuoteItem QuoteItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QuoteItem"
    ADD CONSTRAINT "QuoteItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: QuoteItem QuoteItem_quoteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QuoteItem"
    ADD CONSTRAINT "QuoteItem_quoteId_fkey" FOREIGN KEY ("quoteId") REFERENCES public."Quote"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Quote Quote_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Quote"
    ADD CONSTRAINT "Quote_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Quote Quote_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Quote"
    ADD CONSTRAINT "Quote_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Stock Stock_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public."Branch"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Stock Stock_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Subscription Subscription_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Task Task_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Task Task_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TenantActivity TenantActivity_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TenantActivity"
    ADD CONSTRAINT "TenantActivity_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TenantInvoice TenantInvoice_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TenantInvoice"
    ADD CONSTRAINT "TenantInvoice_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_branchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES public."Branch"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 6KQLfaMs85rLOlfu4AfuPTndWJtkw2JrOBV5beheDs9frn48q3ZsEKrSn9dn0La

